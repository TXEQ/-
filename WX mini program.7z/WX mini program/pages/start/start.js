// start.js

Page({

  
  validate: function () {
    wx.navigateTo({
      url: '../wifi_station/tianqi/tianqi',
    })
  },

})